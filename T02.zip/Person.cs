﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {
        public decimal Salary { get; private set; }

        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            private set { firstName = value; }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            private set { lastName = value; }
        }

        private int age;
        public int Age
        {
            get { return age; }
            private set { age = value; }
        }


        public Person(string firstName, string lastName, int age, decimal salary)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
            this.Salary = salary;
        }

        public void IncreaseSalary(decimal percentage)
        {
            if (age > 30)
            {
                Salary = Salary * (percentage * 0.01m + 1);

            }
            else
            {
                Salary += Salary * percentage / 200;

            }
        }

        public override string ToString()
        {
            return $"{firstName} {lastName} receives {Salary:f2} leva.";
        }
    }
}
